package com.example.hmanager1

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class BMICalculatorActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bmi_calculator)

        val heightInput = findViewById<EditText>(R.id.height_input)
        val weightInput = findViewById<EditText>(R.id.weight_input)
        val calculateButton = findViewById<Button>(R.id.calculate_bmi_button)
        val bmiResult = findViewById<TextView>(R.id.bmi_result)
        val backToMainButton = findViewById<Button>(R.id.back_to_main_button)

        // Calculate BMI
        calculateButton.setOnClickListener {
            val heightText = heightInput.text.toString()
            val weightText = weightInput.text.toString()

            if (heightText.isNotEmpty() && weightText.isNotEmpty()) {
                val height = heightText.toDouble() / 100 // Convert to meters
                val weight = weightText.toDouble()
                val bmi = weight / (height * height)

                val resultText = when {
                    bmi <= 18.5 -> "BMI: %.1f\n저체중입니다.".format(bmi)
                    bmi <= 23 -> "BMI: %.1f\n정상입니다.".format(bmi)
                    bmi <= 25 -> "BMI: %.1f\n과체중입니다.".format(bmi)
                    else -> "BMI: %.1f\n비만입니다.".format(bmi)
                }
                bmiResult.text = resultText
            } else {
                bmiResult.text = "키와 몸무게를 모두 입력하세요."
            }
        }

        // Back to Main Menu
        backToMainButton.setOnClickListener {
            finish() // 현재 Activity를 종료하여 MainActivity로 돌아감
        }
    }
}
