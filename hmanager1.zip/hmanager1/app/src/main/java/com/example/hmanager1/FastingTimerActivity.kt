package com.example.hmanager1

import android.os.Bundle
import android.os.CountDownTimer
import android.text.TextUtils
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class FastingTimerActivity : AppCompatActivity() {

    private var timer: CountDownTimer? = null
    private var timerRunning = false
    private var remainingTimeMillis: Long = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fasting_timer)

        val timerDisplay = findViewById<TextView>(R.id.timer_display)
        val quick8HrsButton = findViewById<Button>(R.id.quick_8hrs)
        val quick12HrsButton = findViewById<Button>(R.id.quick_12hrs)
        val quick16HrsButton = findViewById<Button>(R.id.quick_16hrs)
        val customTimeInput = findViewById<EditText>(R.id.custom_time_input)
        val startButton = findViewById<Button>(R.id.start_timer_button)
        val resetButton = findViewById<Button>(R.id.reset_timer_button)
        val backToMainButton = findViewById<Button>(R.id.back_to_main_button)

        // Start Timer Function
        fun startTimer(hours: Long) {
            remainingTimeMillis = hours * 3600000 // Convert hours to milliseconds
            if (timerRunning) {
                timer?.cancel()
            }
            timer = object : CountDownTimer(remainingTimeMillis, 1000) {
                override fun onTick(millisUntilFinished: Long) {
                    val hours = millisUntilFinished / 3600000
                    val minutes = (millisUntilFinished % 3600000) / 60000
                    val seconds = (millisUntilFinished % 60000) / 1000
                    timerDisplay.text = String.format("%02d:%02d:%02d", hours, minutes, seconds)
                }

                override fun onFinish() {
                    timerDisplay.text = "00:00:00"
                    Toast.makeText(applicationContext, "단식 시간이 끝났습니다!", Toast.LENGTH_SHORT).show()
                }
            }
            timer?.start()
            timerRunning = true
        }

        // Handle Quick Buttons
        quick8HrsButton.setOnClickListener {
            startTimer(8)
        }

        quick12HrsButton.setOnClickListener {
            startTimer(12)
        }

        quick16HrsButton.setOnClickListener {
            startTimer(16)
        }

        // Handle Custom Time Input
        startButton.setOnClickListener {
            val customTime = customTimeInput.text.toString()
            if (!TextUtils.isEmpty(customTime)) {
                val timeParts = customTime.split(":")
                if (timeParts.size == 3) {
                    val hours = timeParts[0].toLong()
                    startTimer(hours)
                } else {
                    Toast.makeText(applicationContext, "올바른 시간 형식 (HH:MM:SS)을 입력하세요.", Toast.LENGTH_SHORT).show()
                }
            }
        }

        // Reset Timer
        resetButton.setOnClickListener {
            timer?.cancel()
            timerDisplay.text = "00:00:00"
            timerRunning = false
        }

        // Back to Main Menu
        backToMainButton.setOnClickListener {
            finish() // 현재 Activity를 종료하여 MainActivity로 돌아감
        }
    }
}
