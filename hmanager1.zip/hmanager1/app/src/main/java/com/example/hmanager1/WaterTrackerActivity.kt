package com.example.hmanager1

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class WaterTrackerActivity : AppCompatActivity() {

    private var waterCount = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_water_tracker)

        val waterCountTextView = findViewById<TextView>(R.id.water_count)
        val decrementButton = findViewById<Button>(R.id.decrement_button)
        val incrementButton = findViewById<Button>(R.id.increment_button)
        val backToMainButton = findViewById<Button>(R.id.back_to_main_button)

        // Update count display
        fun updateWaterCount() {
            waterCountTextView.text = waterCount.toString()
        }

        // Increment button functionality
        incrementButton.setOnClickListener {
            waterCount++
            updateWaterCount()
        }

        // Decrement button functionality
        decrementButton.setOnClickListener {
            if (waterCount > 0) {
                waterCount--
            }
            updateWaterCount()
        }

        // Back to main menu functionality
        backToMainButton.setOnClickListener {
            finish() // 현재 Activity를 종료하여 MainActivity로 돌아감
        }

        // Initialize count display
        updateWaterCount()
    }
}
