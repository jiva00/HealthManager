package com.example.hmanager1

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 물 마신 횟수 기록기 버튼
        findViewById<Button>(R.id.water_tracker_button).setOnClickListener {
            // 물 마신 횟수 기록기 액티비티로 이동
            val intent = Intent(this, WaterTrackerActivity::class.java)
            startActivity(intent)
        }

        // BMI 계산기 버튼
        findViewById<Button>(R.id.bmi_calculator_button).setOnClickListener {
            // BMI 계산기 액티비티로 이동
            val intent = Intent(this, BMICalculatorActivity::class.java)
            startActivity(intent)
        }

        // 단식 타이머 버튼
        findViewById<Button>(R.id.fasting_timer_button).setOnClickListener {
            // 단식 타이머 액티비티로 이동
            val intent = Intent(this, FastingTimerActivity::class.java)
            startActivity(intent)
        }
    }
}
