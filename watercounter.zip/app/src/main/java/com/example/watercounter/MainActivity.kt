package com.example.watercounter

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    // 물 마신 횟수를 기록할 변수
    private var waterCount = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // 시스템 바 여백 적용
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // 레이아웃에서 요소 참조
        val tvWaterCount: TextView = findViewById(R.id.tvWaterCount)
        val btnAddWater: Button = findViewById(R.id.btnAddWater)

        // 버튼 클릭 리스너 설정
        btnAddWater.setOnClickListener {
            waterCount++ // 횟수 증가
            tvWaterCount.text = waterCount.toString() // 텍스트 뷰 갱신
        }
    }
}
