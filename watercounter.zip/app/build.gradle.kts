plugins {
    alias(libs.plugins.android.application) // 기존 방식 유지
    alias(libs.plugins.kotlin.android) // 기존 방식 유지
}

android {
    namespace = "com.example.watercounter" // 기존 네임스페이스 유지
    compileSdk = 34 // 최신 SDK 사용

    defaultConfig {
        applicationId = "com.example.watercounter" // 기존 유지
        minSdk = 24 // 최소 SDK
        targetSdk = 34 // 최신 타겟 SDK
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = "11"
    }
}

dependencies {
    // 기존 방식 유지, 필요한 라이브러리만 추가
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material) // Material 라이브러리

    // 추가적으로 필요한 라이브러리 직접 선언
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.9.0")

    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
}
